# Experiment: Secure Authentication System Using JWT

## Aim
To design and implement a secure authentication system using JSON Web Tokens (JWT) for user login and session management.

## Objectives
1. Register users with securely hashed passwords.
2. Authenticate users using email and password.
3. Issue a signed JWT after successful login.
4. Protect private routes by validating the JWT.
5. Demonstrate token expiry and logout by removing the token on the client.

## Requirements
- Python 3.10+
- Flask
- PyJWT
- Werkzeug (installed with Flask)

## Theory
JWT is a compact, signed token format commonly used to carry claims between a client and a server. A token typically contains a header, payload, and signature. The signature lets the server detect tampering; it does not encrypt the payload, so secrets must not be placed inside it.

This demo uses:
- Password hashing via Werkzeug (passwords are never stored as plain text).
- HS256 JWT signatures.
- A configurable secret key.
- Token expiration.
- A decorator that protects the `/api/me` endpoint.

**Session note:** This is a learning demo. The token is stateless, so “logout” in this example means deleting the token from the client. A copied token remains valid until expiry. For production, use HTTPS, a strong secret stored in environment variables or a secret manager, rate limiting, account recovery controls, and consider refresh-token rotation/revocation and secure HttpOnly cookies.

## Project structure
```text
jwt_authentication_experiment/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── test_app.py
└── README.md
```

## Installation and execution
1. Install Python 3.10 or later.
2. Open a terminal in this folder.
3. Create and activate a virtual environment:
   - Windows: `py -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Set a secret key (recommended):
   - Windows PowerShell: `$env:JWT_SECRET="replace-with-a-long-random-secret"`
   - macOS/Linux: `export JWT_SECRET="replace-with-a-long-random-secret"`
6. Run: `python app.py`
7. API base URL: `http://127.0.0.1:5000`

## API endpoints
### `POST /api/register`
JSON body:
```json
{"username":"student1","email":"student1@example.com","password":"ExamplePass123!"}
```
Creates an account. Password must be at least 8 characters.

### `POST /api/login`
JSON body:
```json
{"email":"student1@example.com","password":"ExamplePass123!"}
```
Returns a signed JWT and basic user details.

### `GET /api/me`
Header:
```text
Authorization: Bearer <token>
```
Returns the authenticated user's profile if the token is valid and not expired.

### `GET /api/health`
Returns a simple health status.

## Example test with curl
Register:
```bash
curl -X POST http://127.0.0.1:5000/api/register -H "Content-Type: application/json" -d "{\"username\":\"student1\",\"email\":\"student1@example.com\",\"password\":\"ExamplePass123!\"}"
```
Login:
```bash
curl -X POST http://127.0.0.1:5000/api/login -H "Content-Type: application/json" -d "{\"email\":\"student1@example.com\",\"password\":\"ExamplePass123!\"}"
```
Copy the returned `access_token`, then:
```bash
curl http://127.0.0.1:5000/api/me -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

## Algorithm
1. Start the Flask server and load the JWT secret and expiry setting.
2. Receive registration details and validate required fields.
3. Hash the password and store the user record.
4. Receive login credentials and find the registered user.
5. Verify the password hash.
6. If valid, generate a signed JWT with user ID, issue time, and expiry.
7. For protected requests, extract the Bearer token and verify its signature and expiry.
8. Return protected data only when validation succeeds; otherwise return an error response.

## Expected result
A user can register, log in, receive a JWT, and access the protected profile endpoint with a valid token. Invalid credentials, malformed tokens, and expired tokens are rejected.

## Result
The experiment demonstrates JWT-based authentication and protection of an API route using password hashing, token signature validation, and expiry checks.
